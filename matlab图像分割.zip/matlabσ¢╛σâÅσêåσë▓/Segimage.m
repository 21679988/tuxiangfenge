function varargout = Segimage(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Segimage_OpeningFcn, ...
    'gui_OutputFcn',  @Segimage_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Segimage is made visible.
function Segimage_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
set(gcf,'name','��ϵ΢�� matlab674  ');
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = Segimage_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

% -----����ͼ��
function inputimage_Callback(hObject, eventdata, handles)
[filename, pathname] = uigetfile( ...
    {'*.bmp;*.jpg;*.png;*.tif;*.jpeg', 'Image Files (*.bmp;*.jpg;*.png;*.tif;*.jpeg)'; ...
    '*.*',                   'All Files (*.*)'}, ...
    'Pick an Image');
axes(handles.axes_src);
fpath=[pathname filename];
img_src=imread(fpath);
global S
S=img_src;
imshow(img_src);
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦ΢�� matlab674  \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return

% -----���ƻҶ�ֱ��ͼ
function imhist_Callback(hObject, eventdata, handles)
global S
figure,imhist(S)

% --------------------------------------------------------------------
function Thresholdmethod_Callback(hObject, eventdata, handles)
% hObject    handle to Thresholdmethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Edgedet_Callback(hObject, eventdata, handles)
% hObject    handle to Edgedet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Areamethod_Callback(hObject, eventdata, handles)
% hObject    handle to Areamethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% ----����ʽ��ֵ


% -------Otsu��ֵ��
function otsu_Callback(hObject, eventdata, handles)


% ------��ˮ�뷨
function watershed_Callback(hObject, eventdata, handles)


% --------------------------------------------------------------------
function roberts_Callback(hObject, eventdata, handles)
% hObject    handle to roberts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function sobel_Callback(hObject, eventdata, handles)
% hObject    handle to sobel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function prewitt_Callback(hObject, eventdata, handles)
% hObject    handle to prewitt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function log_Callback(hObject, eventdata, handles)
% hObject    handle to log (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function canny_Callback(hObject, eventdata, handles)
% hObject    handle to canny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% ------������Ѻϲ���
function fenhe_Callback(hObject, eventdata, handles)



% --- �˳�
function exit_Callback(hObject, eventdata, handles)
clc;
close all;
close(gcf);
clear;





% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
